package com.example.marisco.myapplication;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    Button login_button;
    EditText username_input, password_input;
    Retrofit retrofit;
    TextView tokenID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.login_button = findViewById(R.id.login_button);
        this.username_input = findViewById(R.id.username_input);
        this.password_input = findViewById(R.id.password_input);

        this.tokenID = findViewById(R.id.tokenID);

        this.login_button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                loginUser(username_input.getText().toString(), password_input.getText().toString());
            }
        });
    }

    public void loginUser(String username, String password){

        if(retrofit == null){
            retrofit = new Retrofit.Builder()
                    .baseUrl("https://blissful-land-196114.appspot.com/rest/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }

        AgniAPI agniAPI = retrofit.create(AgniAPI.class);

        Call<LoginResponse> call = agniAPI.loginUser(new User(username_input.getText().toString(), password_input.getText().toString()));

        call.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                tokenID.setVisibility(View.VISIBLE);
                tokenID.setText(response.body().getTokenID());
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Log.e("ERROR", t.toString());
            }
        });

    }
}
